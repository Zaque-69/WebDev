from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login as dj_login
from django.contrib.auth.decorators import login_required
from .forms import UserRegistrationForm
from .forms import LoginForm
# Create your views here.
def home(request) : 
    return render(request, "index.html")

def login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            usern = form.cleaned_data.get('username')
            passw = form.cleaned_data.get('password')
            # Autentificarea utilizatorului (logica specifică)
            user = authenticate(request, username = usern, password = passw)
            

            if user is not None : 
                dj_login(request, user)
                return redirect('home')
    else:
        form = LoginForm()
    return render(request, 'login.html', {
        'form': form
    })
    
def register(request):
    form = UserRegistrationForm()

    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)

        try : form.save()
        except : pass

        usern = request.POST.get('username')
        passw = request.POST.get('password1')
        
        user = authenticate(request, username = usern, password = passw)
        dj_login(request, user)
        return redirect('home')
    
    return render(request, 'register.html', {
        'form' : form
        })
