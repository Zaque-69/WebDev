let slideIndex2 = 0;
let test = 0;

function changeImg() {
  let i;
  let slides = document.getElementsByClassName("change");
  
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex2++;
  if (slideIndex2 > slides.length){
    slideIndex2 = 1;
  }    
  slides[slideIndex2-1].style.display = "block";  
  console.log(slideIndex - 1);
 
}

changeImg();