var list = ["assets/gallery/png1.png", "assets/gallery/png2.png","assets/gallery/png3.png", "assets/gallery/png.png", "assets/gallery/png5.png"];
function choosePic() {
    randomNum = Math.floor(Math.random() * list.length);
    selectedImage = list[randomNum];
    document.getElementById("imageShower").src = selectedImage;
}
choosePic()