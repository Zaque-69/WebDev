const light = document.querySelector('.light');
const dark = document.querySelector('.dark');
const body = document.querySelector('body');
const reg = document.querySelector('.reg');
const sel = document.querySelector('.random');

const lst = ['blue', 'yellow', 'red'];

light.addEventListener('click', changeLight);
dark.addEventListener('click',  changeDark);
sel.addEventListener('click',  changeColor);

function changeLight(){
	body.style.backgroundColor = '#C6C6C6';
	reg.style.backgroundColor = '#C6C6C6';
}
function changeDark(){
	body.style.backgroundColor = "#525252";
	reg.style.backgroundColor = '#525252';
}
function changeColor(){
	let random = Math.floor(Math.random()*lst.lenght);
	body.style.backgroundColor = lst[random];
}