function showElements(){
    document.addEventListener("DOMContentLoaded", function () {
        const elements = document.querySelectorAll(".fade-in");
      
        function checkVisibility() {
          const triggerBottom = window.innerHeight * 0.85;
      
          elements.forEach((e) => {
            let elementTop = e.getBoundingClientRect().top;
            if (elementTop < triggerBottom) {
              e.classList.add("show");
            }
          });
        }
      
        window.addEventListener("scroll", checkVisibility);
        checkVisibility();
    });
}

function main(){
    showElements()
}

main()