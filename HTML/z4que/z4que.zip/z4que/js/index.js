function getWindowHeight() {
  const container = document.querySelector(".background-container");
  if (container) container.style.height = `${window.innerHeight}px`;
}

function animateElement(elementQuery, elementAnimation, elementOpacity) {
    const element = document.querySelector(elementQuery);
    if ( element ){
        element.style.animation = elementAnimation;
        element.style.opacity = elementOpacity;
    }
}

function change_background( passion, passionBackground, hideElements ){
    document.querySelector("#" + passion).addEventListener("mouseover", function(){
        animateElement(passionBackground, "fade-in .4s", "1");
        for ( let i = 0; i < hideElements.length; i++ ){
            animateElement("#" + hideElements[i], "fade-out .4s", "0");
        }
    })
}

function hide_background( passion, passionBackground, hideElements ){
    document.querySelector("#" + passion).addEventListener("mouseout", function(){
        animateElement(passionBackground, "fade-out .3s", "0")
        for ( let i = 0; i < hideElements.length; i++ ){
            animateElement("#" + hideElements[i], "fade-in .3s", "1");
        }
    })
}

function animateBackground( passion, passionBackground, hideElements ){
    change_background( passion, passionBackground, hideElements );
    hide_background( passion, passionBackground, hideElements );
}

function main(){
    getWindowHeight();
    animateBackground("p", ".programming", ["social-button-1", "social-button-2","span-title-1", "span-title-2", "linux", "cybersecurity", "l", "c"]);
    animateBackground("c", ".cybersecurity", ["social-button-1", "social-button-2","span-title-1", "span-title-2", "programming", "linux", "p", "l"]);
    animateBackground("l", ".linux", ["social-button-1", "social-button-2","span-title-1", "span-title-2", "cybersecurity", "programming", "c", "p"]);
}

main()