let selectedAnswers = {};

function toggleAnswer(element, question, answer) {
    if (selectedAnswers[question] === answer) {
        element.classList.remove("selected");
        delete selectedAnswers[question];
        return;
    }

    document.querySelectorAll(`.answer[data-question='${question}']`).forEach(el => {
        el.classList.remove("selected");
    });

    element.classList.add("selected");
    selectedAnswers[question] = answer;
}

function checkAnswers() {
    let score = 0;

    const correctAnswers = {
        q1: "c",
        q2: "c",
        q3: "a",
        q4: "b",
        q6: "b",
        q7: "a",
        q8: "d",
        q9: "a",
        q10 : "b"
    };

    document.querySelectorAll(".answer").forEach(el => {
        let question = el.getAttribute("data-question");
        let answer = el.innerText.charAt(0).toLowerCase(); 

        el.classList.remove("correct", "incorrect");

        if (correctAnswers[question] === answer) {
            el.classList.add("correct");
        }

        if (selectedAnswers[question] && selectedAnswers[question] !== correctAnswers[question]) {
            document.querySelector(`.answer[data-question='${question}'].selected`).classList.add("incorrect");
        }
    });

    for (let key in correctAnswers) {
        if (selectedAnswers[key] === correctAnswers[key]) {
            score++;
        }
    }

    document.getElementById("result").innerHTML = "Ai răspuns corect la " + score + "/9 întrebări!";
}