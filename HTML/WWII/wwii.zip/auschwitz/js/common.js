function fullscreenWindow(){
    document.querySelectorAll(".fullscreen").forEach(e => {
      e.style.minHeight = window.innerHeight + "px";
    })
  }

function main(){
    fullscreenWindow()
    console.log("applied")
}

main()