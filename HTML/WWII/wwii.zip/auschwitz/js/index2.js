function changeImage(index = 0) {
  links = [
    "https://www.fondsk.ru/sites/default/files/images/news/2024/08/14/konc140824.jpg",
    "https://avatars.mds.yandex.net/i?id=aa836ea40722ce85be3661099212b712a8f545bc-5879173-images-thumbs&n=13",
    "https://www.usatoday.com/gcdn/-mm-/f17e207668598cb8e9a50d76c6cf9db673aaf8ab/c=0-208-2013-1345/local/-/media/2015/01/25/USATODAY/USATODAY/635577955290192618-auschwitzxDFHx011.jpg?width=700&height=396&fit=crop&format=pjpg&auto=webp",
    "https://commons.wikimedia.org/wiki/File:Buchenwald_Prisoners_83718.jpg"
  ];
  document.querySelectorAll(".changeImage").forEach(e => {
    e.style.opacity = 0;
    setTimeout(() => {
        e.src = `assets/jpg/zappel${index}.jpg`; 
        e.style.opacity = 1;
    }, 500); 

    let nextIndex = index % 4 + 1;
    document.querySelector(".inner").innerHTML = links[nextIndex - 1];
  setTimeout(() => changeImage(nextIndex), 8000);
  });
}

function main() { 
  window.addEventListener("load", () => changeImage());

}

main()

