/*
  am redus div-ul cu gif-ul la 20% din marimea ecranului calculata la Reload, 
  5% pemtru bara neagra (nav) si restul de 70% pentru imagine
*/
document.querySelector(".gif").style.height = window.innerHeight * 0.25 + "px";
document.querySelector(".nav").style.height = window.innerHeight * 0.05 + "px";
document.querySelector(".main").style.height = window.innerHeight * 0.7 + "px";
document.querySelector(".grad").style.height = window.innerHeight * 0.7 + "px";

/* 
  functie pentru a arata (display) meniul corespunzator fiecarui buton din navigation (JQuery)
*/
function showInfo(elem){
  $('.navinfo').show();
  $(document).ready(function() {
    $('#popup' + elem).click(function() {
      $('#menu' + elem).toggle( "fast", function(){});
    });
  
    $(document).click(function(event) { 
      if(!$(event.target).closest('#popup' + elem, '#menu' + elem).length) {
        if($('#menu' + elem).is(":visible")) {
          $('#menu' + elem).hide();
        }
      }        
    });
  });
}

/*
  aici selectam toate listele din clasa 'navinfo' si le dam proprietatea
  'display : none' din CSS pentru ca isi dau display automat folosing JQuery
*/
document.querySelectorAll('.navinfo *').forEach(function(element) {
  try { document.getElementById(element.id).style.display = "none"; }
  catch {}
});

/*
  nu am mai stat sa insir toate functiile pentru butoanele din nav 1asa ca le am bagat intr-un 'for'
*/
list = [
  "Surse",
  "DespreNoi"
];

for ( let i = 0; i < list.length; i++){
  showInfo(list[i]);
}

$(document).ready(function() {
  $(window).scroll(function() {
    $('.fade-in').each(function() {
      var position = $(this).offset().top;
      var scrollPosition = $(window).scrollTop();
      var windowHeight = $(window).height();
      if (position < scrollPosition + windowHeight - 100) {
        $(this).addClass('visible');
      }
    });
  });
});


var gifs = [
  "gifs/giphy.gif",
  "gifs/giphy1.gif",
  "gifs/giphy2.gif",
  "gifs/giphy3.gif",
  "gifs/giphy4.gif"
];

function randomChoice(arr) {
  return arr[Math.floor(arr.length * Math.random())];
}

function changeBackgroundImage() {
  console.log(randomChoice(gifs));
  document.querySelector(".gif").style.backgroundImage = `url(${randomChoice(gifs)})`;
  setTimeout(changeBackgroundImage, 5000); 
}
changeBackgroundImage()