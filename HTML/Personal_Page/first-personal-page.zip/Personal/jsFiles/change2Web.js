function changeProjects(blockElement, noneElement){
    document.getElementById(blockElement).style.display = "none";
    document.getElementById(noneElement).style.display = "block";
}

function getRandomInt(min, max) {
    return Math.floor(Math.random() * (min, max) + min);
  }

var zero = 0;
function rot(){
    if ( zero == 0 ){
        const list = [
            document.getElementById("pol1"), document.getElementById("pol2"), document.getElementById("pol3")
        ];
        for(var i = 1; i <= 3; i++){
            var randomNumber = getRandomInt(4, 6)
            if (randomNumber == 0 ) randomNumber++;
            list[i-1].style.animation = "rotation " + randomNumber + "s infinite linear";
            list[i-1].style.opacity = "1";
        }
    }
    zero++;
}
//filem
const blockProkects = [ "scrapy", "qrcode", "filem"];
function showScrapy(element){ 
    document.getElementById(element).style.display = "block";
    window.scrollTo(0, 200);
    for (var j = 0; j < blockProkects.length; j++){
        if (blockProkects[j] != element){
            try {
                document.getElementById(blockProkects[j]).style.display = "none";
            }
            catch{}
        }
    }
}
