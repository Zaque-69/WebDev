function changeRed(){
	document.getElementById("myImage").src="assets/adidas/rosu.png";
}
function changeBlue(){
	document.getElementById("myImage").src="assets/adidas/blue.png";
}
function changeAlb(){
	document.getElementById("myImage").src="assets/adidas/alb.png";
}